// language_Chinese.h : main header file for the language_Chinese DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// Clanguage_ChineseApp
// See language_Chinese.cpp for the implementation of this class
//

class Clanguage_ChineseApp : public CWinApp
{
public:
	Clanguage_ChineseApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
